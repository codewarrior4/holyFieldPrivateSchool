<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class index extends Model
{
    //
}
