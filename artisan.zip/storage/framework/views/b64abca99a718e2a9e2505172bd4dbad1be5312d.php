<?php $__env->startSection('content'); ?>

<body class="blog_1 mean-container">
    <!-- Preloader -->
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>


    <header id="header">
        <div class="header-body">
            <nav class="navbar edu-navbar bg-light" >
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    </div>

                    <div class="collapse navbar-collapse edu-nav main-menu" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav">

                            <li><a href="/index"><img src="images/logox.png" width="130" height="130" alt=""></a></li>
                            <li><a data-scroll="" href="/index">Home</a></li>
                            <li><a data-scroll="" href="/admission">Admission</a></li>
                            <li><a data-scroll="" href="/teacher">Teachers</a></li>
                            <li><a data-scroll href="/event">Event</a></li>
                            <li><a data-scroll href="/gallery">Gallery</a></li>
                            <li><a data-scroll href="/blog">Blog</a></li>
                            <li><a data-scroll href="/about">About</a></li>
                            <li><a data-scroll href="/contact">Contact</a></li>
						<li style="display:none"><a data-scroll href="/contact">Contact</a></li>

                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container -->
            </nav>

            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="intro-text ">
                            <h1> School News</h1>
                            <p><span><a href="/index">Home <i class="fa fa-angle-right"></i></a></span> <span class="b-active">Blog</span></p>
                        </div>
                    </div>
                </div><!-- /.row -->
            </div><!-- /.container -->
        </div>
    </header>


    <div class="blog-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-8 bolg_side-left">

                    <?php $__currentLoopData = $allnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-12 single-item-box">
                        <div class="single-item">
                                <a href="blog/<?php echo e($news->id); ?>"><img src="/<?php echo e($news->image); ?>" alt="" class="" style="background-size:cover" height="300"></a>
                                <span><a href="blog/<?php echo e($news->id); ?>" class="overlay"></a></span>
                            <div class="single-text-box">
                                <h3><a href="blog/<?php echo e($news->id); ?>">Students in Class Room</a></h3>
                                <ul class="list-unstyled">
                                    <li><a href="#">By <?php echo e($news->poster); ?></a></li>
                                    <li><a href="#"><?php echo e($news->created_at); ?></a></li>
                                </ul>
                                <p></p>
                                <div class="blog-btn-box">
                                    <a href="blog/<?php echo e($news->id); ?>">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <center><?php echo e($allnews->links()); ?></center>
                </div>

                <div class="col-sm-4 blog_side-right">
                    <div class="sidebar-content">
                        <div class="col-sm-12 recent-post-01">
                            <h3>Student's News</h3>
                            <div class="row">

                               <?php $__currentLoopData = $studentnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $snews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <div class="row">


                               <div class="col-sm-12 recent-single " style="margin-top:12px;margin-bottom:7px;">
                                <div class="recent-content-item">
                                    <div class="img-box"><a href="blog/<?php echo e($snews->id); ?>"><img src="/<?php echo e($snews->image); ?>" alt=""></a></div>
                                    <div class="recent-text pull-right">
                                        <a href="blog/<?php echo e($snews->id); ?>"><?php echo e($snews->title); ?></a>
                                        <p> <span class="content"><i class="fa fa-calendar"></i><?php echo e($snews->created_at); ?></span></p>
                                    </div>
                                </div>
                            </div></div>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\holy_field\resources\views/blog/index.blade.php ENDPATH**/ ?>