<?php $__env->startSection('content'); ?>

<div id="loading-wrapper">
    <div class="spinner-border" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>
<!-- Loading ends -->


<!-- Page wrapper start -->
<div class="page-wrapper">

    <!-- Sidebar wrapper start -->
    <?php echo $__env->make('adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sidebar wrapper end -->

    <!-- Page content start  -->
    <div class="page-content">

        <!-- Header start -->
        <?php echo $__env->make('adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header end -->

        <!-- Page header start -->
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Home</li>
                <li class="breadcrumb-item active">Add Gallery</li>
            </ol>
        </div>
        <!-- Page header end -->

        <!-- Main container start -->
            <!-- Custom Data tables -->
 <div class="main-container">

    <div class="row gutters">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

            <form action="<?php echo e(action('admingalleryController@store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="title">Image Caption</label>
                    <input type="text" required name="caption" id="" class="form-control">
                </div>


                <div class="form-group">
                    <label for="pic">Gallery Image</label>
                    <input type="file" required name="image" id="pic" class="form-control">
                </div>

                <div class="form-group">
                    <input type="submit" value="Add Image" class="btn btn-primary">
                </div>
            </form>

        </div>

    </div>


</div>
        <!-- Main container end -->

    </div>
    <!-- Page content end -->

</div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\holy_field\resources\views/admingallery/create.blade.php ENDPATH**/ ?>