<?php $__env->startSection('content'); ?>

<div id="loading-wrapper">
    <div class="spinner-border" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>
<!-- Loading ends -->


<!-- Page wrapper start -->
<div class="page-wrapper">

    <!-- Sidebar wrapper start -->
    <?php echo $__env->make('adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sidebar wrapper end -->

    <!-- Page content start  -->
    <div class="page-content">

        <!-- Header start -->
        <?php echo $__env->make('adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header end -->

        <!-- Page header start -->
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Home</li>
                <li class="breadcrumb-item active">Events List</li>
            </ol>
            <a href="/adminevent/create">Create Event</a>
        </div>
        <!-- Page header end -->

        <!-- Main container start -->
            <!-- Custom Data tables -->
 <div class="main-container">

    <div class="row gutters">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12 ">
                      <div class="card">
                          <img class="card-img-top" src="/<?php echo e($event->image); ?>" alt="">
                          <div class="card-body">
                              <h5 class="card-title"><?php echo e($event->title); ?></h5>
                              <p class="card-text"><?php echo $event->detail; ?></p>
                              <p class="card-text"><i class="icon-location"></i> &nbsp; <?php echo e($event->location); ?></p>
                              <p class="card-text"><i class="icon-calendar"></i> &nbsp; <?php echo e($event->date); ?></p>
                              <p class="card-text"><i class="icon-clock1"></i> &nbsp; <?php echo e($event->time); ?></p>
                          </div>
                          <div class="card-footer">
                            <a href="<?php echo e(url('/adminevent/'.$event->id.'/edit')); ?>" role="button" class="btn  btn-outline-primary btn-md">Edit News</a>
                            <a href="<?php echo e(url('/adminevent/delete/'.$event->id)); ?>" class="btn btn-outline-danger" role="button"> Delete News</a>
                          </div>
                      </div>
                     </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php echo e($lists->links()); ?>


    </div>


</div>
        <!-- Main container end -->

    </div>
    <!-- Page content end -->

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\holy_field\resources\views/adminevent/index.blade.php ENDPATH**/ ?>