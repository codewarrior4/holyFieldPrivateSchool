<?php $__env->startSection('content'); ?>

<div id="loading-wrapper">
    <div class="spinner-border" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>
<!-- Loading ends -->


<!-- Page wrapper start -->
<div class="page-wrapper">

    <!-- Sidebar wrapper start -->
    <?php echo $__env->make('adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sidebar wrapper end -->

    <!-- Page content start  -->
    <div class="page-content">

        <!-- Header start -->
        <?php echo $__env->make('adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header end -->

        <!-- Page header start -->
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">Home</li>
                <li class="breadcrumb-item active">Gallery List</li>
            </ol>
            <a href="/admingallery/create">Add image to Gallery</a>
        </div>
        <!-- Page header end -->

        <!-- Main container start -->
            <!-- Custom Data tables -->
 <div class="main-container">

    <div class="row gutters">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="card col-4">
                       <img class="card-img-top" src="/<?php echo e($gallery->image); ?>" alt="">
                       <div class="card-body">
                           <h5 class="card-title"><?php echo e($gallery->caption); ?></h5>
                       </div>
                       <div class="card-footer">
                        <a href="<?php echo e(url('/admingallery/delete/'.$gallery->id)); ?>" class="btn btn-outline-danger" role="button"> Delete Gallery</a>
                       </div>
                   </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php echo e($galleries->links()); ?>


    </div>


</div>
        <!-- Main container end -->

    </div>
    <!-- Page content end -->

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\holy_field\resources\views/admingallery/index.blade.php ENDPATH**/ ?>