        

        <?php $__env->startSection('content'); ?>

        <div id="loading-wrapper">
            <div class="spinner-border" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Loading ends -->


        <!-- Page wrapper start -->
        <div class="page-wrapper">

            <!-- Sidebar wrapper start -->
            <?php echo $__env->make('adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Sidebar wrapper end -->

            <!-- Page content start  -->
            <div class="page-content">

                <!-- Header start -->
                <?php echo $__env->make('adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Header end -->

                <!-- Page header start -->
                <div class="page-header">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">Home</li>
                        <li class="breadcrumb-item active">Admin Dashboard</li>
                    </ol>

                </div>
                <!-- Page header end -->

                <!-- Main container start -->
                    <!-- Custom Data tables -->
		 <div class="main-container">

            <div class="row gutters">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">

                    <div class="table-container">
						<div class="t-header">No Search Field</div>								<div class="table-responsive">
								<table id="copy-print-csv" class="table custom-table">
									<thead>
										<tr>
                                          <th>S/N</th>
										  <th>Name</th>
										  <th>Email</th>
										  <th>Subject</th>
										  <th>Message</th>
										</tr>
									</thead>
									<tbody>
                                        <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                            <td><?php echo e($message->id); ?></td>
                                            <td><?php echo e($message->name); ?></td>
                                            <td><?php echo e($message->email); ?></td>
                                            <td><?php echo e($message->subject); ?></td>
                                            <td><?php echo e($message->message); ?></td>


                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


									</tbody>
						    	</table>
							</div>
						</div>

                    </div>
            </div>


		</div>
                <!-- Main container end -->

            </div>
            <!-- Page content end -->

        </div>


        <?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\holy_field\resources\views/zeus/contact.blade.php ENDPATH**/ ?>