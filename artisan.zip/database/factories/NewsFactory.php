<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\news;
use Faker\Generator as Faker;

$factory->define(news::class, function (Faker $faker) {
    return [
        //
    ];
});
