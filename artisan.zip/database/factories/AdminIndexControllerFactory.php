<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\adminIndexController;
use Faker\Generator as Faker;

$factory->define(adminIndexController::class, function (Faker $faker) {
    return [
        //
    ];
});
