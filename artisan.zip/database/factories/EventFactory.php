<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\event;
use Faker\Generator as Faker;

$factory->define(event::class, function (Faker $faker) {
    return [
        //
    ];
});
