<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\adminIndex;
use Faker\Generator as Faker;

$factory->define(adminIndex::class, function (Faker $faker) {
    return [
        //
    ];
});
