<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\index;
use Faker\Generator as Faker;

$factory->define(index::class, function (Faker $faker) {
    return [
        //
    ];
});
