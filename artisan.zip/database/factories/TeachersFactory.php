<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\teachers;
use Faker\Generator as Faker;

$factory->define(teachers::class, function (Faker $faker) {
    return [
        //
    ];
});
